package customer;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;

@Path("/Customer")
public class Customer {

//	@GET
//	@Produces(MediaType.APPLICATION_JSON)
//	public String saysHello()
//	{
//		return "{\"customer_name\": \"Arpan Ghoshal\",\"rate-arr\":[4,5,5,5],\"comments\" : \"happy for the service\"}";
//	}
	
	private MongoClient mongoClient;
	private DBCollection collection;
	
	 public MongoClient getMongoClient() throws Exception {
		 this.mongoClient=MongoDemo.ConnectToDB();
		 return mongoClient;
	}

	 public DBCollection getCollection() throws Exception {
		 DB db=getMongoClient().getDB("mycustomers");
		 this.collection=db.getCollection("customersFeedback");
		 return collection;
	}
	


	 @POST
	 @Path("/insert")
	 @Consumes(MediaType.APPLICATION_JSON)
	 public String postStrMsg(String input) {
		try {
	        MongoDemo.InsertJSONParse(getCollection(), input);
	        return "Successfully Inserted Data";
		}
	        catch(Exception ex){
	        	return "Error in inserting data";	        	
	        }
	        
	        
	    }
}
