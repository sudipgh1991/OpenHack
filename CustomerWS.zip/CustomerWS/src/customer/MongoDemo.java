package customer;
import java.util.ArrayList;
import java.util.List;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;

public class MongoDemo {
	
	public static MongoClient ConnectToDB() throws Exception
	{
		
		try {
			MongoClient mongoClient=new MongoClient("localhost",27017);
			return mongoClient;
			}
			catch(Exception e)
			{
				throw new Exception("Unable to connect databases");
			}
			
	}
	
	public static void ReadAllData(DBCollection coll) throws Exception
	{
		try {
		
		DBCursor cursor=coll.find();
		
		while(cursor.hasNext())
		{
			System.out.println(cursor.next());
		}
		
		}
		catch(Exception ex)
		{
			throw new Exception("Not able to Read Data from db");
		}
	}
	
	public static void ReadSpecificrecord(DBCollection coll, String name) throws Exception
	{
		try {
		
		
		BasicDBObject whereQuery = new BasicDBObject();
		whereQuery.put("customer_name",name);
		DBCursor cursor = coll.find(whereQuery);
		while(cursor.hasNext()) {
		    System.out.println(cursor.next());
		}
		}
		catch(Exception ex)
		{
			throw new Exception("Error in trying to read specific data");
		}
		
	}
	
	
	public static void InsertDocument(DBCollection collection) throws Exception
	{
		try
		{
			
			
			BasicDBObject document = new BasicDBObject();
			document.put("customer_name", "Abhijit Dey");
			document.put("comments", "Done Testing");

			List<Integer> ratings=new ArrayList<Integer>();
			ratings.add(3);
			ratings.add(2);
			ratings.add(4);
			ratings.add(5);
			
			document.put("rate-arr", ratings);

			collection.insert(document);
		}
		catch(Exception ex)
		{
			throw new Exception("Error in trying to insert data");
		}
	}
	
	public static void InsertJSONParse(DBCollection coll,String json) throws Exception
	{
		try
		{
			DBObject dbObject = (DBObject)JSON.parse(json);

			coll.insert(dbObject);
		}
		catch(Exception ex)
		{
			throw new Exception("Error in trying to insert data");
		}
	}

}
